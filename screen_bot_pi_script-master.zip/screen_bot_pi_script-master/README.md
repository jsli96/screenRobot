# screen_bot_pi_script
This script is for raspberry pi zero w
